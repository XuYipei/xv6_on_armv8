#ifndef INC_TIMER_H
#define INC_TIMER_H

void timer_init();
void timer_reset();
void timer();

#endif
