#ifndef INC_PERIPHERALS_MBOX_H
#define INC_PERIPHERALS_MBOX_H

#include "peripherals/base.h"

int mbox_get_arm_memory();
int mbox_get_clock_rate();

#endif
